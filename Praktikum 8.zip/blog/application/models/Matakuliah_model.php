<?php

// Buat Class
class Matakuliah_model extends CI_Model{
    // Buat Struktur Data
    public $nama_matkul, $sks, $dosen, $kode;

}

?>